"""
Binding Pocket Descriptor Calculator
=====================================
Given a PDB ID, identifies the ligand-defined binding pocket and computes:
  - Surface area (SASA of pocket residues)
  - Depth and shape indices (sphericity, elongation)
  - Ligandability (heuristic druggability score)
  - Electrostatic potential at the pocket (approximate, Coulombic)

Requirements:
    pip install biopython scipy numpy

Note on electrostatics: this uses a simplified distance-dependent-dielectric
Coulomb sum over formal residue charges as a quick descriptor. It is NOT a
Poisson-Boltzmann solution. For rigorous ESP, run PDB2PQR + APBS and sample
the .dx grid at the pocket surface instead.
"""

import warnings
import numpy as np
from Bio.PDB import PDBParser, PDBList
from Bio.PDB.SASA import ShrakeRupley
from scipy.spatial import ConvexHull

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------- config ---
POCKET_CUTOFF = 6.0  # A, protein residues within this distance of the ligand

EXCLUDE_RESNAMES = {
    "HOH", "WAT", "NA", "CL", "MG", "ZN", "CA", "K", "MN", "FE", "CU",
    "SO4", "PO4", "GOL", "EDO", "DMS", "PEG", "ACT", "FMT", "TRS", "IOD",
}

HYDROPHOBIC = {"ALA", "VAL", "LEU", "ILE", "PRO", "PHE", "MET", "TRP"}
CHARGE_MAP = {"ASP": -1.0, "GLU": -1.0, "LYS": 1.0, "ARG": 1.0, "HIS": 0.1}


# ------------------------------------------------------------- fetch/io ---
def fetch_structure(pdb_id, out_dir="./pdb_cache"):
    """Download (if needed) and parse a PDB structure by 4-letter ID."""
    pdbl = PDBList(verbose=False)
    fname = pdbl.retrieve_pdb_file(pdb_id, pdir=out_dir, file_format="pdb")
    parser = PDBParser(QUIET=True)
    return parser.get_structure(pdb_id, fname)


def load_structure_from_file(path, structure_id="STRUCT"):
    """Parse a local PDB file directly (useful for testing / offline use)."""
    parser = PDBParser(QUIET=True)
    return parser.get_structure(structure_id, path)


# ------------------------------------------------------------ ligand id ---
def find_ligand(structure, exclude=EXCLUDE_RESNAMES, ligand_resname=None):
    """
    Identify the bound ligand as the largest HETATM residue that is not
    water/a common crystallization additive/ion. Pass ligand_resname to
    pick a specific residue name if a structure has several ligands.
    """
    candidates = []
    model = structure[0]
    for chain in model:
        for res in chain:
            hetflag = res.id[0]
            is_het = hetflag != " "
            if not is_het or res.resname in exclude:
                continue
            if ligand_resname and res.resname != ligand_resname:
                continue
            candidates.append((len(list(res.get_atoms())), res))
    if not candidates:
        return None
    candidates.sort(key=lambda x: -x[0])
    return candidates[0][1]


# --------------------------------------------------------- pocket atoms ---
def get_pocket_residues(structure, ligand, cutoff=POCKET_CUTOFF):
    """Protein residues with at least one atom within `cutoff` A of the ligand."""
    lig_coords = np.array([a.coord for a in ligand.get_atoms()])
    pocket_residues = []
    for chain in structure[0]:
        for res in chain:
            if res is ligand or res.id[0] != " ":  # protein residues only
                continue
            for atom in res:
                if np.min(np.linalg.norm(lig_coords - atom.coord, axis=1)) <= cutoff:
                    pocket_residues.append(res)
                    break
    return pocket_residues


# -------------------------------------------------------------- descriptors ---
def compute_surface_area(structure, pocket_residues):
    """Sum of per-residue SASA (Shrake-Rupley) restricted to pocket residues."""
    sr = ShrakeRupley()
    sr.compute(structure[0], level="R")
    return sum(getattr(res, "sasa", 0.0) for res in pocket_residues)


def compute_shape_descriptors(pocket_residues):
    """Convex-hull-based volume, surface area, sphericity, elongation, depth."""
    coords = np.array([res["CA"].coord for res in pocket_residues if "CA" in res])
    if len(coords) < 4:
        return None
    hull = ConvexHull(coords)
    volume, area = hull.volume, hull.area

    r_eq = (3 * volume / (4 * np.pi)) ** (1 / 3)
    sphericity = (4 * np.pi * r_eq ** 2) / area if area > 0 else 0.0

    centered = coords - coords.mean(axis=0)
    eigvals = np.sort(np.linalg.eigvalsh(np.cov(centered.T)))[::-1]
    elongation = eigvals[0] / eigvals[-1] if eigvals[-1] > 1e-6 else float("inf")

    centroid = coords.mean(axis=0)
    depth = np.max(np.linalg.norm(coords - centroid, axis=1))

    return {
        "hull_volume_A3": volume,
        "hull_surface_area_A2": area,
        "sphericity": sphericity,
        "elongation": elongation,
        "depth_A": depth,
    }


def compute_ligandability(pocket_residues):
    """Heuristic druggability score from pocket size + hydrophobic composition."""
    n = len(pocket_residues)
    if n == 0:
        return {"n_pocket_residues": 0, "hydrophobic_ratio": 0.0, "ligandability_score": 0.0}
    hydrophobic_ratio = sum(r.resname in HYDROPHOBIC for r in pocket_residues) / n
    size_score = max(0.0, min(1.0, 1.0 - abs(n - 25) / 25))  # peaks near 25 residues
    score = 0.5 * hydrophobic_ratio + 0.5 * size_score
    return {
        "n_pocket_residues": n,
        "hydrophobic_ratio": hydrophobic_ratio,
        "ligandability_score": score,
    }


def compute_electrostatic_potential(pocket_residues, ligand_centroid, dielectric=4.0):
    """
    Approximate ESP at the ligand centroid: sum of formal side-chain charges
    weighted by a 1/(eps*r^2) distance-dependent-dielectric Coulomb term.
    Quick/relative descriptor only -- see module docstring.
    """
    k = 332.0  # kcal*A / (mol*e^2)
    potential = 0.0
    for res in pocket_residues:
        q = CHARGE_MAP.get(res.resname, 0.0)
        if q == 0.0 or "CA" not in res:
            continue
        r = np.linalg.norm(res["CA"].coord - ligand_centroid)
        if r > 0.1:
            potential += k * q / (dielectric * r ** 2)
    return potential


# ------------------------------------------------------------------ driver ---
def analyze_pocket(pdb_id=None, pdb_file=None, ligand_resname=None, cutoff=POCKET_CUTOFF):
    """
    Run the full pipeline for one structure. Provide either pdb_id (fetches
    from RCSB) or pdb_file (local path). Returns a dict of descriptors.
    """
    label = pdb_id or pdb_file
    print(f"\n=== {label} ===")

    structure = fetch_structure(pdb_id) if pdb_id else load_structure_from_file(pdb_file, label)

    ligand = find_ligand(structure, ligand_resname=ligand_resname)
    if ligand is None:
        print("  No ligand found (only water/ions/common additives present).")
        return None
    print(f"  Ligand: {ligand.resname} {ligand.id}")

    pocket_residues = get_pocket_residues(structure, ligand, cutoff=cutoff)
    if not pocket_residues:
        print("  No pocket residues found within cutoff.")
        return None

    sasa = compute_surface_area(structure, pocket_residues)
    shape = compute_shape_descriptors(pocket_residues) or {}
    ligandability = compute_ligandability(pocket_residues)
    lig_centroid = np.mean([a.coord for a in ligand.get_atoms()], axis=0)
    esp = compute_electrostatic_potential(pocket_residues, lig_centroid)

    results = {
        "id": label,
        "ligand": ligand.resname,
        "surface_area_A2": round(sasa, 2),
        **{k: round(v, 3) for k, v in shape.items()},
        **{k: (round(v, 3) if isinstance(v, float) else v) for k, v in ligandability.items()},
        "electrostatic_potential_approx": round(esp, 3),
    }
    for k, v in results.items():
        print(f"    {k}: {v}")
    return results


if __name__ == "__main__":
    # Replace with your own PDB ID list
    pdb_ids = ["5XGI", "2WNC", "5DTM", "2XJ1", "1XAP", "4TXC","6H36","6OW7","3TAM"]
    all_results = [r for r in (analyze_pocket(pdb_id=pid) for pid in pdb_ids) if r]