macrotarget = 'C:\Users\Arkadeep Sarkar\Desktop\plan_of_work\matisse_paper\Accounts of chemical research\submission\paper_raw_data\seq_vol_compare\6hfs_matisse_similarity_validation\negative\dock'
scenefile= 'C:\Users\Arkadeep Sarkar\Desktop\plan_of_work\matisse_paper\Accounts of chemical research\submission\paper_raw_data\seq_vol_compare\6hfs_matisse_similarity_validation\sce_files'
CD (macrotarget)
OnError stop
ForceField AMBER03,SetPar=No 
Longrange None
Cutoff 10.50000 
Interactions Bond,Angle,Dihedral,Planarity,Coulomb,VdW 

CD (macrotarget)
def dock macrotarget, name
  lnumber= CountMol L
  if lnumber ==1 or lnumber >1
    Cell Auto, Extension=5.0,Shape=Cube,Mol L
    DelMol L
    LoadPDB (macrotarget)/lig.pdb
    Experiment Docking 
      ResultFile (macrotarget)/(name)_001.yob
      ClusterRMSD 5.00 
      Runs 50    
      Method VINA    
      LigandObj 2    
      ReceptorObj 1    
    Experiment On
    Wait ExpEnd 

  if lnumber ==0
    Cell Auto, Extension=5.0,Shape=Cube
    Experiment Docking 
      ResultFile (macrotarget)/(name)_001.yob
      ClusterRMSD 5.00 
      Runs 50    
      Method VINA    
      LigandObj selected    
      ReceptorObj 1    
    Experiment On
    Wait ExpEnd      
  for can=002 to 50
    DelFile (macrotarget)/(name)_(can).yob 

for line in file C:\Users\Arkadeep Sarkar\Desktop\plan_of_work\matisse_paper\Accounts of chemical research\submission\paper_raw_data\seq_vol_compare\6hfs_matisse_similarity_validation\negative\pdb_list.txt
  print (line)
  exist= Filesize '(scenefile)\(line).sce'
  if !exist
    LoadPDB (line),Download=latest  
    include C:\Users\Arkadeep Sarkar\Desktop\plan_of_work\matisse_paper\the_final_script/PDBCLEAN_listcleanFAST.mcr
    Experiment Minimization
    Experiment On
    Wait ExpEnd
    DelObj simcell
    SaveSce (scenefile)/(line).sce
    clear

DelTab all    
MakeTab 1,Dimensions=1
for line in file C:\Users\Arkadeep Sarkar\Desktop\plan_of_work\matisse_paper\Accounts of chemical research\submission\paper_raw_data\seq_vol_compare\6hfs_matisse_similarity_validation\negative\pdb_list.txt
  print (line)
  #LoadSce '(scenefile)/(line).sce'
  #NameMol !AminoAcid !Metal !water,L 
  #dock macrotarget, line
  #DelObj all
  LoadYob (macrotarget)/(line)_001.yob
  Tabulate '(line)'
  B = BFactormol L
  Tabulate (0.000+B)
  DelObj all
  #Clear
  
SaveTab 1, (macrotarget)\Result_VINA_Dock.txt,Format=Text,Columns=2,NumFormat=6.2f, Target   Affinity   
clear

      