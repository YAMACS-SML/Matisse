"""
Batch computation of binding-site volumes for a list of PDB IDs, using the
DoGSite3 REST API on proteins.plus (Fahrrolfes et al., NAR 2017; Volkamer
lab). For each PDB entry:

  1. The bound ligand is auto-detected via the PDBe ligand_monomers API
     (crystallization additives / ions such as SO4, GOL, EDO, water, etc.
     are ignored). If more than one chain carries a ligand, the first one
     found is used ("any one", as requested).
  2. The structure + ligand are submitted to DoGSite3 with ligand-biased
     pocket detection, so the returned pocket set is centered on the
     bound ligand.
  3. The pocket with the best ligand/pocket coverage (lig_cov, poc_cov) is
     selected as "the" binding site, and its volume (in A^3) is reported.

DoGSite3 REST API docs: https://proteins.plus/help/dogsite3_rest
PDBe ligand API docs:   https://www.ebi.ac.uk/pdbe/api/doc/pdb.html

Install deps:  pip install requests
"""

import csv
import io
import time

import requests

PDBE_LIGANDS_URL = "https://www.ebi.ac.uk/pdbe/api/pdb/entry/ligand_monomers/{}"
DOGSITE3_SUBMIT_URL = "https://proteins.plus/api/dogsite3_rest"

# Common crystallization additives, cryoprotectants and ions to skip when
# auto-picking "the" ligand. Extend this set if your PDBs contain other
# buffer components you want ignored.
EXCLUDE_HET = {
    "HOH", "WAT", "SO4", "PO4", "GOL", "EDO", "DMS", "ACT", "TRS", "MPD",
    "PEG", "PG4", "PGE", "P6G", "IMD", "IOD", "NA", "CL", "MG", "CA", "ZN",
    "MN", "K", "FE", "FE2", "NI", "CO", "CD", "BR", "NO3", "FMT", "EPE",
    "BME", "MES", "CIT", "ACY", "1PE", "BOG", "SIN", "TLA", "OXL", "UNK",
    "UNX", "MRD", "CO3", "SR", "CS", "LI", "RB", "CU", "GSH", "DTT",
}


def get_binding_ligand(pdb_id):
    """Return (chem_comp_id, chain_id, author_residue_number) for the first
    non-additive ligand found in the entry, or None if there isn't one.
    If ligands sit on several chains, only the first encountered is used.
    """
    r = requests.get(PDBE_LIGANDS_URL.format(pdb_id.lower()), timeout=30)
    if r.status_code == 404:
        return None
    r.raise_for_status()
    entries = r.json().get(pdb_id.lower(), [])
    for entry in entries:
        comp_id = entry.get("chem_comp_id", "")
        if comp_id.upper() in EXCLUDE_HET:
            continue
        chain = entry.get("chain_id")
        resnum = entry.get("author_residue_number")
        if chain is None or resnum is None:
            continue
        return comp_id, chain, resnum
    return None


def submit_dogsite3_job(pdb_id, chain_id, ligand_str, ligand_bias=True):
    """Submit a job to DoGSite3 and return the job location URL to poll."""
    payload = {
        "dogsite3": {
            "pdbCode": pdb_id.lower(),
            "analysisDetail": "1",                 # include subpockets
            "bindingSitePredictionGranularity": "1",  # include druggability
            "ligand": ligand_str,
            "chain": chain_id,
            "ligandBias": "1" if ligand_bias else "0",
        }
    }
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    r = requests.post(DOGSITE3_SUBMIT_URL, json=payload, headers=headers, timeout=30)
    r.raise_for_status()
    resp = r.json()
    if "location" not in resp:
        raise RuntimeError(f"Unexpected DoGSite3 submission response: {resp!r}")
    return resp["location"]


def poll_job(job_location, max_attempts=30, wait_seconds=10):
    """Poll a submitted job until the result table is ready."""
    for _ in range(max_attempts):
        r = requests.get(job_location, timeout=30)
        if r.status_code == 429:
            time.sleep(wait_seconds)
            continue
        r.raise_for_status()
        resp = r.json()
        if resp.get("result_table"):
            return resp
        time.sleep(wait_seconds)
    raise TimeoutError(f"DoGSite3 job at {job_location} did not finish in time.")


def parse_result_table(result_table_url):
    r = requests.get(result_table_url, timeout=30)
    r.raise_for_status()
    return list(csv.DictReader(io.StringIO(r.text), delimiter="\t"))


def pick_ligand_pocket(rows, ligand_str):
    """Pick the pocket best covering the target ligand (by lig_cov, then
    poc_cov). Falls back to the largest-volume pocket if none is tagged
    with the ligand (can happen for very small/solvent-exposed ligands).
    """
    candidates = [row for row in rows if row.get("lig_name") == ligand_str]
    if candidates:
        candidates.sort(
            key=lambda r: (float(r["lig_cov"]), float(r["poc_cov"])), reverse=True
        )
        return candidates[0]
    if rows:
        return max(rows, key=lambda r: float(r["volume"]))
    return None


def compute_binding_site_volume(pdb_id):
    result = {
        "pdb_id": pdb_id, "ligand": None, "chain": None,
        "pocket": None, "volume": None, "status": "ok", "error": None,
    }
    try:
        lig = get_binding_ligand(pdb_id)
        if lig is None:
            result["status"] = "no_ligand_found"
            return result

        comp_id, chain, resnum = lig
        ligand_str = f"{comp_id}_{chain}_{resnum}"
        result["ligand"], result["chain"] = ligand_str, chain

        job_location = submit_dogsite3_job(pdb_id, chain, ligand_str)
        job_result = poll_job(job_location)
        rows = parse_result_table(job_result["result_table"])

        best = pick_ligand_pocket(rows, ligand_str)
        if best is None:
            result["status"] = "no_pocket_found"
            return result

        result["pocket"] = best.get("name")
        result["volume"] = float(best["volume"])
    except Exception as exc:  # keep going over the rest of the list
        result["status"] = "error"
        result["error"] = str(exc)
    return result


def batch_compute(pdb_ids, out_csv="binding_site_volumes.csv", delay=10.0):
    """Run compute_binding_site_volume over a list of PDB IDs and write a
    CSV summary. `delay` throttles requests to be polite to the free
    proteins.plus server."""
    results = []
    for pdb_id in pdb_ids:
        pdb_id = pdb_id.strip()
        if not pdb_id:
            continue
        print(f"[{pdb_id}] processing...", end=" ", flush=True)
        res = compute_binding_site_volume(pdb_id)
        print(res["status"], "-", res.get("volume"))
        results.append(res)
        time.sleep(delay)

    fieldnames = ["pdb_id", "ligand", "chain", "pocket", "volume", "status", "error"]
    with open(out_csv, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    print(f"\nSaved results -> {out_csv}")
    return results


def read_pdb_ids(path):
    """Read PDB IDs from a text file, one per line (blank lines and lines
    starting with '#' are ignored)."""
    with open(path) as fh:
        return [
            line.strip() for line in fh
            if line.strip() and not line.strip().startswith("#")
        ]


if __name__ == "__main__":
    import sys

    # Usage: python dogsite3_binding_site_volume.py [input_ids.txt] [output.csv]
    in_path = sys.argv[1] if len(sys.argv) > 1 else "missing_id.txt"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "binding_site_volumes.csv"

    pdb_ids = read_pdb_ids(in_path)
    print(f"Loaded {len(pdb_ids)} PDB IDs from {in_path}")
    batch_compute(pdb_ids, out_csv=out_path,delay=10.0)