"""
Batch computation of binding-site volumes for a list of PDB IDs, using the
DoGSite3 REST API on proteins.plus (Fahrrolfes et al., NAR 2017; Volkamer
lab). For each PDB entry:

  1. The bound ligand is auto-detected via the PDBe ligand_monomers API
     (crystallization additives / ions such as SO4, GOL, EDO, water, etc.
     are ignored). If more than one chain carries a ligand, the first one
     found is used ("any one", as requested).
  2. The structure + ligand are submitted to DoGSite3 with ligand-biased
     pocket detection, so the returned pocket set is centered on the
     bound ligand.
  3. The pocket with the best ligand/pocket coverage (lig_cov, poc_cov) is
     selected as "the" binding site, and its volume (in A^3) is reported.

DoGSite3 REST API docs: https://proteins.plus/help/dogsite3_rest
PDBe ligand API docs:   https://www.ebi.ac.uk/pdbe/api/doc/pdb.html

Install deps:  pip install requests
"""

import csv
import io
import time

import requests

PDBE_LIGANDS_URL = "https://www.ebi.ac.uk/pdbe/api/pdb/entry/ligand_monomers/{}"
DOGSITE3_SUBMIT_URL = "https://proteins.plus/api/dogsite3_rest"

# Common crystallization additives, cryoprotectants and ions to skip when
# auto-picking "the" ligand. Extend this set if your PDBs contain other
# buffer components you want ignored.
EXCLUDE_HET = {
    "HOH", "WAT", "SO4", "PO4", "GOL", "EDO", "DMS", "ACT", "TRS", "MPD",
    "PEG", "PG4", "PGE", "P6G", "IMD", "IOD", "NA", "CL", "MG", "CA", "ZN",
    "MN", "K", "FE", "FE2", "NI", "CO", "CD", "BR", "NO3", "FMT", "EPE",
    "BME", "MES", "CIT", "ACY", "1PE", "BOG", "SIN", "TLA", "OXL", "UNK",
    "UNX", "MRD", "CO3", "SR", "CS", "LI", "RB", "CU", "GSH", "DTT",
}


def _retry(func, *, retries=4, base_wait=5.0, retry_on_429=True, label=""):
    """Call func() with retries and exponential backoff. Retries on network
    errors and on HTTP 429 (server throttling). Re-raises the last error
    if all attempts are exhausted, with a clear label of which step failed.
    """
    last_exc = None
    for attempt in range(1, retries + 1):
        try:
            return func()
        except requests.exceptions.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else None
            last_exc = exc
            if status == 429 and retry_on_429:
                wait = base_wait * attempt
                print(f"  [{label}] throttled (429), retry {attempt}/{retries} in {wait:.0f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(f"{label} failed (HTTP {status}): {exc}") from exc
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
            last_exc = exc
            wait = base_wait * attempt
            print(f"  [{label}] network error, retry {attempt}/{retries} in {wait:.0f}s: {exc}")
            time.sleep(wait)
            continue
    raise RuntimeError(f"{label} failed after {retries} attempts: {last_exc}") from last_exc


def get_binding_ligand(pdb_id, session):
    """Return (chem_comp_id, chain_id, author_residue_number) for the first
    non-additive ligand found in the entry, or None if there isn't one.
    If ligands sit on several chains, only the first encountered is used.
    """
    def _do():
        r = session.get(PDBE_LIGANDS_URL.format(pdb_id.lower()), timeout=30)
        if r.status_code == 404:
            return "NOT_FOUND"
        r.raise_for_status()
        return r.json().get(pdb_id.lower(), [])

    entries = _retry(_do, label="ligand lookup")
    if entries == "NOT_FOUND":
        return None
    for entry in entries:
        comp_id = entry.get("chem_comp_id", "")
        if comp_id.upper() in EXCLUDE_HET:
            continue
        chain = entry.get("chain_id")
        resnum = entry.get("author_residue_number")
        if chain is None or resnum is None:
            continue
        return comp_id, chain, resnum
    return None


def submit_dogsite3_job(pdb_id, chain_id, ligand_str, session, ligand_bias=True):
    """Submit a job to DoGSite3 and return the job location URL to poll."""
    payload = {
        "dogsite3": {
            "pdbCode": pdb_id.lower(),
            "analysisDetail": "1",                 # include subpockets
            "bindingSitePredictionGranularity": "1",  # include druggability
            "ligand": ligand_str,
            "chain": chain_id,
            "ligandBias": "1" if ligand_bias else "0",
        }
    }
    headers = {"Content-Type": "application/json", "Accept": "application/json"}

    def _do():
        r = session.post(DOGSITE3_SUBMIT_URL, json=payload, headers=headers, timeout=30)
        r.raise_for_status()
        resp = r.json()
        if "location" not in resp:
            raise RuntimeError(f"Unexpected DoGSite3 submission response: {resp!r}")
        return resp["location"]

    return _retry(_do, label="job submission")


def poll_job(job_location, session, max_attempts=30, wait_seconds=10):
    """Poll a submitted job until the result table is ready."""
    for attempt in range(1, max_attempts + 1):
        try:
            r = session.get(job_location, timeout=30)
            if r.status_code == 429:
                wait = wait_seconds * min(attempt, 6)
                print(f"  [poll] throttled (429), waiting {wait:.0f}s")
                time.sleep(wait)
                continue
            r.raise_for_status()
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
            print(f"  [poll] network error ({exc}), retrying in {wait_seconds}s")
            time.sleep(wait_seconds)
            continue
        resp = r.json()
        if resp.get("result_table"):
            return resp
        time.sleep(wait_seconds)
    raise TimeoutError(f"DoGSite3 job at {job_location} did not finish in time.")


def parse_result_table(result_table_url, session):
    def _do():
        r = session.get(result_table_url, timeout=30)
        r.raise_for_status()
        return list(csv.DictReader(io.StringIO(r.text), delimiter="\t"))

    return _retry(_do, label="result table download")


def pick_ligand_pocket(rows, ligand_str):
    """Pick the pocket best covering the target ligand (by lig_cov, then
    poc_cov). Falls back to the largest-volume pocket if none is tagged
    with the ligand (can happen for very small/solvent-exposed ligands).
    """
    candidates = [row for row in rows if row.get("lig_name") == ligand_str]
    if candidates:
        candidates.sort(
            key=lambda r: (float(r["lig_cov"]), float(r["poc_cov"])), reverse=True
        )
        return candidates[0]
    if rows:
        return max(rows, key=lambda r: float(r["volume"]))
    return None


def compute_binding_site_volume(pdb_id):
    """Runs the full pipeline for one PDB ID on a brand-new requests.Session
    (no connection/state reuse from previous IDs) so a prior failure or
    throttle can't bleed into the next entry."""
    result = {
        "pdb_id": pdb_id, "ligand": None, "chain": None,
        "pocket": None, "volume": None, "status": "ok", "error": None,
    }
    session = requests.Session()
    try:
        lig = get_binding_ligand(pdb_id, session)
        if lig is None:
            result["status"] = "no_ligand_found"
            return result

        comp_id, chain, resnum = lig
        ligand_str = f"{comp_id}_{chain}_{resnum}"
        result["ligand"], result["chain"] = ligand_str, chain

        job_location = submit_dogsite3_job(pdb_id, chain, ligand_str, session)
        job_result = poll_job(job_location, session)
        rows = parse_result_table(job_result["result_table"], session)

        best = pick_ligand_pocket(rows, ligand_str)
        if best is None:
            result["status"] = "no_pocket_found"
            return result

        result["pocket"] = best.get("name")
        result["volume"] = float(best["volume"])
    except Exception as exc:  # keep going over the rest of the list
        result["status"] = "error"
        result["error"] = str(exc)
    finally:
        session.close()
    return result


def batch_compute(pdb_ids, out_csv="binding_site_volumes.csv", delay=3.0):
    """Run compute_binding_site_volume over a list of PDB IDs and write a
    CSV summary after EVERY entry (not just at the end), so partial
    progress survives a crash/interrupt. `delay` throttles requests to be
    polite to the free proteins.plus server."""
    fieldnames = ["pdb_id", "ligand", "chain", "pocket", "volume", "status", "error"]
    results = []
    for pdb_id in pdb_ids:
        pdb_id = pdb_id.strip()
        if not pdb_id:
            continue
        print(f"[{pdb_id}] processing...")
        res = compute_binding_site_volume(pdb_id)
        print(f"  -> status={res['status']} volume={res.get('volume')}"
              + (f" error={res['error']}" if res.get("error") else ""))
        results.append(res)

        # Write after every ID so you always have the latest results on disk.
        with open(out_csv, "w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(results)

        time.sleep(delay)

    print(f"\nSaved results -> {out_csv}")
    return results


if __name__ == "__main__":
    # List your PDB IDs directly here - no input file needed.
    pdb_ids = ["5O9Q", "2AZ8", "4LYW", "1EBK", "7CO8", "1PXP", "6DGX"]
    batch_compute(pdb_ids, out_csv="binding_site_volumes.csv")