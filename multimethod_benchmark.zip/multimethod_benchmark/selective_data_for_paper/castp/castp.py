import csv
import time
import urllib.parse
import webbrowser
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import requests
import re
import json
import os
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os




path= input("Insert the path of PDB list.txt: ")
namefile= input("Insert the name of pdb list .txt file: ")


def cerca_parola(url, parola):
    try:
        # Make GET request to the web page
        response = requests.get(url)
        response.raise_for_status()  # Check for errors in the request

        #  Extract the HTML text from the response
        html_text = response.text

        # Use regular expressions to search for the word in HTML text
        matches = re.findall(r'\b{}\b'.format(parola), html_text, re.IGNORECASE)

        # Return the number of occurrences found
        return len(matches)
    except requests.exceptions.RequestException as e:
        print("An error occurred during the request:", str(e))
    except Exception as e:
        print("An error occurred:", str(e))

def get_gene_information(path,pdb_file_path):
    # Generate the URL for human species
    human_url = f"http://sts.bioe.uic.edu/castp/calculation.html"
    pagefile=os.path.join(path,"page.html")
    # Configure Chrome driver options to run in headless mode
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--log-level=3")  # Set the log level to 'warning'.

    # Initialise the Chrome driver with options
    driver = webdriver.Chrome(options=chrome_options)
    driver.get(human_url)

    # Wait a while for the page to load
    time.sleep(8)

# Find the file input element
    file_input =driver.find_element(By.ID,"pdbfile")
    file_input.send_keys(pdb_file_path)
    time.sleep(8)
    submit_button = driver.find_element(By.ID, "btn_submit")
    submit_button.click()

    # Wait for 5 seconds before saving the page as HTML
    time.sleep(15)

    # Save the page as HTML
    with open(pagefile, "w") as file:
        file.write(driver.page_source)

    # Close the browser
    driver.quit()

pdbfilepath = os.path.join(path,namefile)
result=os.path.join(path,"result_data.txt")

k= open(result, "w+") 
k.write("id surface_area surface_volume\n")
k.close()
with open(pdbfilepath, 'r') as file:
    # Iterate through each line in the file
    for line in file:
        # Strip any leading/trailing whitespaces and print the line
        pdbfilename=(line.strip())
        pdb_file_path =os.path.join(path,pdbfilename)
        get_gene_information(path,pdb_file_path)
        pageinformation= os.path.join(path,"page.html")
        with open(pageinformation, "r") as file:
            html_content = file.read()

        pagesoup = BeautifulSoup(html_content, "html.parser")

        # Find the link element by its ID
        job_link_element = pagesoup.find("a", id="joblink")

        if job_link_element:
            # Extract the link URL
            job_link = job_link_element["href"]

            # Print the link
            print("Generated Job Link:", job_link)
            chrome_options = Options()
            chrome_options.add_argument("--headless")
            chrome_options.add_argument("--log-level=3")
            driver = webdriver.Chrome(options=chrome_options)
            driver.get(job_link)

            # Wait a while for the page to load
            time.sleep(8)
            joblinkfile= os.path.join(path,"joblink.html")
            with open(joblinkfile, "w") as file:
                file.write(driver.page_source)

            # Close the browser
            driver.quit()
            with open(joblinkfile, "r") as file:
                html_content = file.read()

            soupdata = BeautifulSoup(html_content, "html.parser")

            # Find all <td> elements with class "ng-binding"
            td_elements = soupdata.find_all("td", class_="ng-binding")

            # Extract the values from the td_elements
            values = [td.get_text() for td in td_elements]

            # Print the values
            second_value = values[1]
            third_value = values[2]
            second_value= str(second_value)
            third_value= str(third_value)
            print(second_value,third_value)
            
            result=os.path.join(path,"result_data.txt")
            h= open(result, "a") 
            h.write(str(pdbfilename)+" "+str(second_value)+" "+str(third_value)+"\n")
            h.close()
                               
                
        else:
            print("Job link element not found.")
