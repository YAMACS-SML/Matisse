Dir= '/home/picasso/Desktop/metisse/selective_data_for_paper'
CD (Dir)
filenamelist() =  '3AMR', '6DGX'
#filenamelist() = ListDir *.sce
for filename in filenamelist
  LoadSce (filename)
  nome = NameObj 1
  o()= crack nome
  JoinObj all,1
  name=o1+o2+o3+o4
  SavePDB 1, (name)
  Clear
